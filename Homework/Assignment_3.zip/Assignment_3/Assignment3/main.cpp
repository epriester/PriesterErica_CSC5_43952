/* 
 * File:   main.cpp
 * Author: Erica Priester
 * Created on March 30, 2015
 * Purpose:
 */

//System Libraries
#include <iostream>
using namespace std;


//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables

    //Prompt user for Input

    //Calculations

    //Output the Results

    //Exit stage right!
    return 0;
}

